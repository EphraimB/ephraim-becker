# Kosherizer
A Google Chrome extension that makes the loaded webpage more kosher by replacing all the curse words and inappropiate words on the webpage with their appropiate counterparts
